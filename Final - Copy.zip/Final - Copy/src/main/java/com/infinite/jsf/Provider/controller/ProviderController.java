package com.infinite.jsf.Provider.controller;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import com.infinite.jsf.Provider.dao.ProviderDao;
import com.infinite.jsf.Provider.dao.ProviderDaoImpl;
import com.infinite.jsf.Provider.model.OtpToken;
import com.infinite.jsf.Provider.model.Provider;
import com.infinite.jsf.Provider.util.SessionHelper;

@ManagedBean(name = "providerController")
@SessionScoped
public class ProviderController implements Serializable {

    private static final long serialVersionUID = 1L;
 

    private ProviderDao dao = new ProviderDaoImpl();// Type=providerDao , implementations=providerDaoimpl
    private Provider currentProvider;

    private String email;
    private String password;
    private String oldPassword;
    private String newPassword;
    private String confirmPassword;
    private String otp;
// ____________For resend OTP timer___________
    
    private long otpExpiryMillis;

    public long getOtpExpiryMillis() {
      return otpExpiryMillis;
    }
    public void setOtpExpiryMillis(long otpExpiryMillis) {
      this.otpExpiryMillis = otpExpiryMillis;
    }
//____________reset sucessful message__________
    
private boolean resetSuccess = false;

// ─── SIGNUP ─────────────────────────────────────────────────────────────
 public String signup() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        try {
            if (newPassword == null || !newPassword.equals(confirmPassword)) {
                throw new Exception("Passwords must match.");
            }

            Provider p = new Provider();
            p.setEmail(email);
            p.setPasswordHash(newPassword);
            dao.signup(p);

            ctx.addMessage(null,
                new FacesMessage("Signup successful! Please log in."));
            return "login.jsp?faces-redirect=true";

        } catch (Exception e) {
            ctx.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
            return null;
        }
    }

    // ─── LOGIN ──────────────────────────────────────────────────────────────
  public String login() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        try {
            currentProvider = dao.login(email, password);
            SessionHelper.getConnection();
            ctx.getExternalContext()
               .getSessionMap()
               .put("currentProvider", currentProvider);

            return "dashboard.jsp?faces-redirect=true";

        } catch (Exception e) {
            ctx.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
            return null;
        }
    }

    // ─── LOGOUT ─────────────────────────────────────────────────────────────
  public String logout() {
        FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .invalidateSession();
        currentProvider = null;
        return "login.jsp?faces-redirect=true";
    }

    // ─── CHANGE PASSWORD ────────────────────────────────────────────────────
  public String changePassword() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        try {
            if (newPassword == null || !newPassword.equals(confirmPassword)) {
                throw new Exception("New passwords must match.");
            }

            dao.changePassword(
                currentProvider.getId().intValue(),
                oldPassword,
                newPassword
            );

            ctx.addMessage(null,
                new FacesMessage("Password updated successfully."));
            return "dashboard.jsp?faces-redirect=true";

        } catch (Exception e) {
            ctx.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
            return null;
        }
    }
   
    // ─── SEND FORGOT PASSWORD OTP ───────────────────────────────────────────
   public String sendForgotOtp() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        try {
            // ensure Gmail address
           // if (email == null || !email.matches(".\\.com$")) {// if (email == null || !email.matches(".*@gmail\\.com$"))
               
        	if (email == null || !email.toLowerCase().endsWith(".com")) {
        	    // true if email is null or doesn’t end with “.com”
        	
              throw new Exception("Email must end with .com");
            }

            dao.sendForgotPasswordOtp(email);

            // fetch latest OTP expiration to drive JS timer
            OtpToken token = dao.getLatestOtpForEmail(email);
            this.otpExpiryMillis = token.getExpiresAt().getTime();

            ctx.addMessage(null,
                new FacesMessage("OTP sent. Check your email."));
            // Made by sourav
          //  Provider pd = new Provider();
          //  pd= null;
            return "verify-otp.jsp?faces-redirect=true";

        } catch (Exception e) {
            ctx.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
            return null;
        }
    }

    // ─── RESEND OTP ─────────────────────────────────────────────────────────
    public String resendOtp() {
         sendForgotOtp();
        //return "verify-otp.jsp?faces-redirect=true";
         return null;
    }

    // ─── VERIFY OTP & RESET PASSWORD ───────────────────────────────────────
    public boolean isResetSuccess() {
        return resetSuccess;
    }

    public void setResetSuccess(boolean resetSuccess) {
        this.resetSuccess = resetSuccess;
    }

    // 🔐 Core Logic
    public String verifyOtpAndReset() {
        FacesContext ctx = FacesContext.getCurrentInstance();

        try {
            boolean hasError = false;

            if (otp == null || otp.trim().isEmpty()) {
                ctx.addMessage("resetForm:otp",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Please enter the OTP.", null));
                hasError = true;
            }

            if (newPassword == null || newPassword.trim().isEmpty()) {
                ctx.addMessage("resetForm:newPwd",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Please enter the new password.", null));
                hasError = true;
            }

            if (confirmPassword == null || confirmPassword.trim().isEmpty()) {
                ctx.addMessage("resetForm:confirmPwd",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Please enter the confirm password.", null));
                hasError = true;
            }

            if (hasError) {
                resetSuccess = false;
                return null;
            }

            if (!newPassword.equals(confirmPassword)) {
                throw new Exception("Passwords must match.");
            }

            if (!dao.validateForgotPasswordOtp(email, otp)) {
                throw new Exception("Invalid or expired OTP.");
            }

            Provider p = dao.findByEmail(email);
            dao.completeForgotPassword(p.getId().intValue(), newPassword);

            resetSuccess = true;
            ctx.addMessage(null,
                new FacesMessage("Password reset successful. Please log in."));
            return null; // stay on page to show popup and allow redirect via JS

        } catch (Exception e) {
            resetSuccess = false;
            ctx.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
            return null;
        }
    }
    
   /*
    public String verifyOtpAndReset() {
        FacesContext ctx = FacesContext.getCurrentInstance();

        try {
            boolean hasError = false;

            if (otp == null || otp.trim().isEmpty()) {
                ctx.addMessage("resetForm:otp",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Please enter the OTP.", null));
                hasError = true;
            }

            if (newPassword == null || newPassword.trim().isEmpty()) {
                ctx.addMessage("resetForm:newPwd",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Please enter the new password.", null));
                hasError = true;
            }

            if (confirmPassword == null || confirmPassword.trim().isEmpty()) {
                ctx.addMessage("resetForm:confirmPwd",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Please enter the confirm password.", null));
                hasError = true;
            }

            // Stop here if any required fields are missing
            if (hasError) {
                this.resetSuccess = false;
                return null;
            }

            // 1) Password matching
            if (!newPassword.equals(confirmPassword)) {
                throw new Exception("Passwords must match.");
            }

            // 2) OTP Valid
            if (!dao.validateForgotPasswordOtp(email, otp)) {
                throw new Exception("Invalid or expired OTP.");
            }

            // 3) Actually reset
            Provider p = dao.findByEmail(email);
            dao.completeForgotPassword(p.getId().intValue(), newPassword);

            // 4) Signal success
            this.resetSuccess = true;
            ctx.addMessage(null,
                new FacesMessage("Password reset successful. Please log in."));
            return "login.jsp?faces-redirect=true";

        } catch (Exception e) {
            this.resetSuccess = false;
            ctx.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
            return null;
        }
    }
*/
    
    /*public String verifyOtpAndReset() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        try {
        	//1) password matching
            if (newPassword == null || !newPassword.equals(confirmPassword)) {
                throw new Exception("Passwords must match.");
            }
            // 2) OTP Valid
            if (!dao.validateForgotPasswordOtp(email, otp)) {
                throw new Exception("Invalid or expired OTP.");
            }
           // 3) actually reset
            Provider p = dao.findByEmail(email);
            dao.completeForgotPassword(p.getId().intValue(), newPassword);
          // 4) signal success and stay on page
            this.resetSuccess =true;//reset successful message(delete)
            ctx.addMessage(null,
                new FacesMessage("Password reset successful. Please log in."));
            return "login.jsp?faces-redirect=true";
        } catch (Exception e) {
        	this.resetSuccess= false;//reset success message(delete)
            ctx.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
            return null;
        }
    }
*/
    // ─── HELPER ─────────────────────────────────────────────────────────────
    public boolean isLoggedIn() {
        return currentProvider != null;
    }

    // ─── GETTERS & SETTERS ─────────────────────────────────────────────────
    public Provider getCurrentProvider() {
        return currentProvider;
    }

    public void setCurrentProvider(Provider currentProvider) {
        this.currentProvider = currentProvider;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email != null ? email.trim() : null;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }
}
