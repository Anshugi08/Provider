package com.infinite.jsf.Provider.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.jsf.Provider.model.OtpToken;
import com.infinite.jsf.Provider.model.PasswordHistory;
import com.infinite.jsf.Provider.model.Provider;
import com.infinite.jsf.Provider.util.MailSend;
import com.infinite.jsf.Provider.util.OTPGenerator;
import com.infinite.jsf.Provider.util.PasswordEncryptor;
import com.infinite.jsf.Provider.util.SessionHelper;

public class ProviderDaoImpl implements ProviderDao {

    private static final String PASS_REGEX =
        "^(?=.{8,12}$)(?=.*[A-Za-z])(?=.*\\d)(?=.*[^A-Za-z\\d]).*$";

    private SessionFactory sf = SessionHelper.getConnection();

    @Override
    public void signup(Provider provider) throws Exception {
        String raw = provider.getPasswordHash();
        validatePassword(raw);

        String encrypted = PasswordEncryptor.encrypt(raw);
        provider.setPasswordHash(encrypted);

        Session session = null;
        Transaction tx = null;
        try {
            session = sf.openSession();
            tx = session.beginTransaction();

            session.save(provider);
            session.save(new PasswordHistory(provider, encrypted, new Date()));

            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        } finally {
            if (session != null) session.close();
        }
    }

    @Override
    public Provider login(String email, String password) throws Exception {
        Session session = null;
        try {
            session = sf.openSession();
            Query q = session.createQuery("FROM Provider WHERE email = :e");
            q.setParameter("e", email);
            Provider p = (Provider) q.uniqueResult();

            String encryptedInput = PasswordEncryptor.encrypt(password);
            if (p == null || !p.getPasswordHash().equals(encryptedInput)) {
                throw new Exception("Invalid credentials.");
            }
            return p;
        } finally {
            if (session != null) session.close();
        }
    }

    @Override
    public void changePassword(int providerId, String oldPassword, String newPassword) throws Exception {
        validatePassword(newPassword);

        Session session = null;
        Transaction tx = null;
        try {
            session = sf.openSession();
            tx = session.beginTransaction();

            Provider p = (Provider) session.get(Provider.class, (long) providerId);
            if (p == null) {
                throw new Exception("Provider not found.");
            }

            String oldEnc = PasswordEncryptor.encrypt(oldPassword);
            if (!p.getPasswordHash().equals(oldEnc)) {
                throw new Exception("Old password incorrect.");
            }

            if (isAmongLastPasswords(session, p, newPassword)) {
                throw new Exception("Cannot reuse any of the last 3 passwords.");
            }

            String newEnc = PasswordEncryptor.encrypt(newPassword);
            p.setPasswordHash(newEnc);
            session.update(p);
            session.save(new PasswordHistory(p, newEnc, new Date()));

            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        } finally {
            if (session != null) session.close();
        }
    }

    @Override
    public void sendForgotPasswordOtp(String email) throws Exception {
        Session session = null;
        Transaction tx = null;
        try {
            session = sf.openSession();

            Query qUser = session.createQuery("FROM Provider WHERE email = :e");
            qUser.setParameter("e", email);
            Provider p = (Provider) qUser.uniqueResult();
            if (p == null) {
                throw new Exception("Enter correct Email.");//Email not found
            }

            String otp   = OTPGenerator.generateOTP(6);
            Date expires = new Date(System.currentTimeMillis() + (2) * 60 * 1000); // 5 min

            tx = session.beginTransaction();
            // remove any previous OTPs for this user
            session.createQuery("DELETE FROM OtpToken WHERE provider = :p")
                   .setParameter("p", p)
                   .executeUpdate();
            // insert new OTP
            session.save(new OtpToken(p, otp, expires));
            tx.commit();

            try {
                MailSend.sendInfo(email, "OTP Code", "Your OTP is: " + otp);
            } catch (Exception mex) {
                throw new Exception("Failed to send OTP email", mex);
            }

        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw e;
        } finally {
            if (session != null) session.close();
        }
    }

    @Override
    public OtpToken getLatestOtpForEmail(String email) throws Exception {
        Session session = null;
        try {
            session = sf.openSession();

            Query qUser = session.createQuery("FROM Provider WHERE email = :e");
            qUser.setParameter("e", email);
            Provider p = (Provider) qUser.uniqueResult();
            if (p == null) {
                throw new Exception("Email not found.");
            }

            Query qOtp = session.createQuery(
                "FROM OtpToken WHERE provider = :p ORDER BY expiresAt DESC"
            );
            qOtp.setParameter("p", p);
            qOtp.setMaxResults(1);

            return (OtpToken) qOtp.uniqueResult();
        } finally {
            if (session != null) session.close();
        }
    }

    @Override
public boolean validateForgotPasswordOtp(String email, String otpCode) throws Exception {
        OtpToken latest = getLatestOtpForEmail(email);
        return latest != null
            && latest.getToken().equals(otpCode)
            && latest.getExpiresAt().after(new Date());
    }

    @Override
public void completeForgotPassword(int providerId, String newPassword) throws Exception {
        validatePassword(newPassword);

        Session session = null;
        Transaction tx = null;
        try {
            session = sf.openSession();
            tx = session.beginTransaction();
            Provider p = (Provider) session.get(Provider.class, (long) providerId);
            if (p == null) {
                throw new Exception("Provider not found.");
            }

            if (isAmongLastPasswords(session, p, newPassword)) {
                throw new Exception("Cannot reuse any of the last 3 passwords.");
            }

            String newEnc = PasswordEncryptor.encrypt(newPassword);
            p.setPasswordHash(newEnc);
            session.update(p);
            session.save(new PasswordHistory(p, newEnc, new Date()));

            // delete any existing OTPs after success
            session.createQuery("DELETE FROM OtpToken WHERE provider = :p")
                   .setParameter("p", p)
                   .executeUpdate();

            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        } finally {
            if (session != null) session.close();
        }
    }

 @Override
 public Provider findByEmail(String email) throws Exception {
        Session session = null;
        try {
            session = sf.openSession();
            Query q = session.createQuery("FROM Provider WHERE email = :e");
            q.setParameter("e", email);
            return (Provider) q.uniqueResult();
        } finally {
            if (session != null) session.close();
        }
    }

 private boolean isAmongLastPasswords(Session session, Provider p, String newPassword) {
 String newEnc = PasswordEncryptor.encrypt(newPassword);

        Query q = session.createQuery(
            "FROM PasswordHistory WHERE provider = :p ORDER BY createdAt DESC"
        );
        q.setParameter("p", p);
        q.setMaxResults(3);

        @SuppressWarnings("unchecked")
        List<PasswordHistory> last = q.list();
        return last.stream()
                   .anyMatch(ph -> ph.getPasswordHash().equals(newEnc));
    }

 private void validatePassword(String pwd) throws Exception {
        if (pwd == null || !pwd.matches(PASS_REGEX)) {
            throw new Exception(
                "Password must be 8–12 characters long, include letters, digits and a special character."
            );
        }
    }
}
