package com.infinite.jsf.Provider.dao;

import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.jsf.Provider.model.Provider;
import com.infinite.jsf.Provider.model.OtpToken;
import com.infinite.jsf.Provider.model.PasswordHistory;
import com.infinite.jsf.Provider.util.MailSend;
import com.infinite.jsf.Provider.util.OTPGenerator;
import com.infinite.jsf.Provider.util.PasswordEncryptor;
import com.infinite.jsf.Provider.util.SessionHelper;
public class ProviderDaoImpl implements ProviderDao {
	    
	private SessionFactory sf = SessionHelper.getConnection();
	
Transaction tx= null;
Session s= null;
	    @Override
	    public void signup(Provider provider) throws Exception {
	        Session s = null;
	        Transaction tx = null;
	        try {
	            s = sf.openSession();
	            tx = s.beginTransaction();

	            s.save(provider);
	            s.save(new PasswordHistory(provider, provider.getPasswordHash(), new Date()));

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) tx.rollback();
	            throw e;
	        } finally {
	            if (s != null) s.close();
	        }
	    }

	    @Override
	    public Provider login(String usernameOrEmail, String password) throws Exception {
	        Session s = null;
	        try {
	            s = sf.openSession();
	            Query query = s.createQuery("FROM Provider WHERE email = :e");
	            query.setParameter("e", usernameOrEmail);
	            Provider p = (Provider) query.uniqueResult();

	            if (p == null || !p.getPasswordHash().equals(password)) {
	                throw new Exception("Invalid credentials");
	            }
	            return p;
	        } finally {
	            if (s != null) s.close();
	        }
	    }

	    @Override
	    public void changePassword(int providerId, String oldPassword, String newPassword) throws Exception {
	        Session s = null;
	        Transaction tx = null;
	        try {
	            s = sf.openSession();
	            tx = s.beginTransaction();

	            Provider p = (Provider) s.get(Provider.class, (long) providerId);
	            if (p == null) throw new Exception("Provider not found");
	            if (!p.getPasswordHash().equals(oldPassword)) {
	                throw new Exception("Old password incorrect");
	            }
	            if (isAmongLastPasswords(s, p, newPassword)) {
	                throw new Exception("Cannot reuse any of the last 3 passwords");
	            }

	            p.setPasswordHash(newPassword);
	            s.update(p);
	            s.save(new PasswordHistory(p, newPassword, new Date()));

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) tx.rollback();
	            throw e;
	        } finally {
	            if (s != null) s.close();
	        }
	    }

	    @Override
	    public void sendForgotPasswordOtp(String email) throws Exception {
	        Session s = null;
	        Transaction tx = null;
	        try {
	            s = sf.openSession();
	            Query query = s.createQuery("FROM Provider p WHERE p.email = :e");
	            query.setParameter("e", email);
	            Provider p = (Provider) query.uniqueResult();
	            if (p == null) {
	                throw new Exception("Email not found");
	            }

	            String otp = OTPGenerator.generateOTP(6);
	            Date expires = new Date(System.currentTimeMillis() + 10 * 60 * 1000);

	            tx = s.beginTransaction();
	            s.save(new OtpToken(p, otp, expires));
	            tx.commit();

	            // inner try/catch for email sending
	            try {
	                MailSend.sendInfo(email, "OTP Code", "Your OTP is: " + otp);
	            } catch (Exception mex) {
	                // now catches any exception from sendInfo()
	                throw new Exception("Failed to send OTP email", mex);
	            }

	        } catch (Exception e) {
	            if (tx != null && tx.isActive()) {
	                tx.rollback();
	            }
	            throw e;
	        } finally {
	            if (s != null) {
	                s.close();
	            }
	        }
	    }


	    @Override
	    public boolean validateForgotPasswordOtp(int providerId, String otpCode) throws Exception {
	        Session s = null;
	        try {
	            s = sf.openSession();
	            Provider p = (Provider) s.get(Provider.class, (long) providerId);
	            if (p == null) return false;
	            Query query = s.createQuery(
	                "FROM OtpToken WHERE provider = :p AND token = :o ORDER BY expiresAt DESC"
	            );
	            query.setParameter("p", p);
	            query.setParameter("o", otpCode);
	            query.setMaxResults(1);
	            List<OtpToken> tokens = query.list();

	            return !tokens.isEmpty() && tokens.get(0).getExpiresAt().after(new Date());
	        } finally {
	            if (s != null) s.close();
	        }
	    }

	    @Override
	    public void completeForgotPassword(int providerId, String newPassword) throws Exception {
	        Session s = null;
	        Transaction tx = null;
	        try {
	            s = sf.openSession();
	            tx = s.beginTransaction();

	            Provider p = (Provider) s.get(Provider.class, (long) providerId);
	            if (p == null) throw new Exception("Provider not found");
	            if (isAmongLastPasswords(s, p, newPassword)) {
	                throw new Exception("Cannot reuse any of the last 3 passwords");
	            }

	            p.setPasswordHash(newPassword);
	            s.update(p);
	            s.save(new PasswordHistory(p, newPassword, new Date()));

	            Query deleteQ = s.createQuery("DELETE FROM OtpToken WHERE provider = :p");
	            deleteQ.setParameter("p", p);
	            deleteQ.executeUpdate();

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) tx.rollback();
	            throw e;
	        } finally {
	            if (s != null) s.close();
	        }
	    }

	    private boolean isAmongLastPasswords(Session s, Provider p, String newPassword) {
	        Query query = s.createQuery(
	            "FROM PasswordHistory WHERE provider = :p ORDER BY createdAt DESC"
	        );
	        query.setParameter("p", p);
	        query.setMaxResults(3);
	        List<PasswordHistory> last = query.list();

	        return last.stream()
	                   .anyMatch(ph -> ph.getPasswordHash().equals(newPassword));
	    }
	}

   
	
